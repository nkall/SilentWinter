function Base(){
	this.inventory = new Inventory(50,50,0,0,0);
	this.population = 1;
}

Base.prototype.drawBase = function() {
	//TODO
};