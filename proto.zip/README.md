# SilentWinter
Strategy/survival game created for CMPM 20: Game Design Experience

Controls: Use WASD or arrow keys to move, I to view inventory, and E to enter or exit a building. Collect as many supplies as you can before your heat runs out!

Please see src/Assets for concept art, full-size versions of in-game assets, dialogue, music, and more, some of which are not yet implemented into the game.
